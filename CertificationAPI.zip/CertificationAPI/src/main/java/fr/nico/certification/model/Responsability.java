package fr.nico.certification.model;

import java.io.Serializable;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "responsability")
public class Responsability implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	@Column(name = "name")
	private String name;
	
	@Column(name = "ownername")
	private String ownerName;
	
	@Column(name = "owneruid")
	private String ownerUID;

	@OneToMany(mappedBy = "responsability", fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	private List<Decision> decisions;

	
	@Transient
	public String status;
	
	public Responsability() {
		// TODO Auto-generated constructor stub
	}
	
	public Responsability(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}



	public List<Decision> getDecisions() {
		return decisions;
	}

	public void setDecisions(List<Decision> decisions) {
		this.decisions = decisions;
	}


	public String getOwnerUID() {
		return ownerUID;
	}

	public void setOwnerUID(String ownerUID) {
		this.ownerUID = ownerUID;
	}

	public String getStatus() {
		String ret = "";
		Comparator<Decision> comparator = Comparator.comparing(Decision::getDecisionDate);
		Optional<Decision> lastDecision = this.getDecisions().stream().filter(d -> d.getDecisionDate() != null).max(comparator);
		if(!lastDecision.isEmpty()) {
			ret = lastDecision.get().getDecisionName();
		}
		return ret;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	
}
