package fr.nico.certification.data;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

import fr.nico.certification.model.Decision;
import fr.nico.certification.model.Responsability;

@Component
public class SecurityData {

	@PersistenceContext
	public EntityManager em;

	public List<Responsability> listResponsabilities() {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Responsability> query = cb.createQuery(Responsability.class);
		Root<Responsability> all = query.from(Responsability.class);
		query.select(all);
		List<Responsability> responsabilities = em.createQuery(query).getResultList();
		return responsabilities;
	}
	
	@Transactional
	public void decide(Decision d) {
		em.persist(d);
	}
}
