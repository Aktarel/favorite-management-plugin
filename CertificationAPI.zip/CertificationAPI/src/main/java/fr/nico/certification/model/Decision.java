package fr.nico.certification.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table (name = "decision")
public class Decision implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;

	@Column(name = "decisiondate")
	private Date decisionDate;
	
	@Column(name = "decisionname")
	private String decisionName;
	
	@Column(name = "ownerUid")
	private String ownerUID;

	@ManyToOne
	@JoinColumn(name = "responsabilityId")
	@JsonIgnore
	private Responsability responsability;

	public Decision() {
		// TODO Auto-generated constructor stub
	}

	public Decision(String name, Date decisionDate, String ownerUID, int id) {
		this.decisionDate = decisionDate;
		this.decisionName = name;
		this.ownerUID = ownerUID;
		this.responsability = new Responsability(id);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDecisionDate() {
		return decisionDate;
	}

	public void setDecisionDate(Date decisionDate) {
		this.decisionDate = decisionDate;
	}

	public String getDecisionName() {
		return decisionName;
	}

	public void setDecisionName(String decisionName) {
		this.decisionName = decisionName;
	}

	public Responsability getResponsability() {
		return responsability;
	}

	public void setResponsability(Responsability responsability) {
		this.responsability = responsability;
	}

	public String getOwnerUID() {
		return ownerUID;
	}

	public void setOwnerUID(String ownerUID) {
		this.ownerUID = ownerUID;
	}


}
