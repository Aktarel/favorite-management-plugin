package fr.nico.certification.controller;

import java.util.logging.Logger;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;

import fr.nico.certification.data.SecurityData;
import fr.nico.certification.model.AddDecisionBody;
import fr.nico.certification.model.Decision;

@Path("/v1")
public class SecurityService {
	private static final Logger logger = Logger.getLogger(SecurityService.class.getName());

	@Autowired
	private SecurityData data;

	@GET
	@Path("/responsability/list")
	@Produces("application/json")
	public Response list() throws WebApplicationException {
		return Response.ok(data.listResponsabilities()).build();
	}

	@POST
	@Path("/decision")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response decide(@RequestBody AddDecisionBody body) throws WebApplicationException {
		data.decide(new Decision(body.getDecisionName(), body.getDecisionDate(), body.getOwnerUID(), body.getResponsabilityId()));
		return Response.ok("{}").build();
	}

}
