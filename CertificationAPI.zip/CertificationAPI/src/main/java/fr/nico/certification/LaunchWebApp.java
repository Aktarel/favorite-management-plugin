package fr.nico.certification;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import fr.nico.certification.config.RestApplicationConfig;
import fr.nico.certification.controller.SecurityService;

@SpringBootApplication
public class LaunchWebApp {

	public static void main(String[] args) {
		SpringApplication.run(LaunchWebApp.class, args);
	}
	@Bean
	  ResourceConfig resourceConfig() {
		  ResourceConfig rc = new ResourceConfig();
		  rc.register(RestApplicationConfig.class);
		  rc.register(SecurityService.class);
	      return rc;
	  }
}
