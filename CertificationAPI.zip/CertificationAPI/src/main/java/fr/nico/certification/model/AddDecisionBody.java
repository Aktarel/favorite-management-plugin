package fr.nico.certification.model;

import java.util.Date;

public class AddDecisionBody {

	private int responsabilityId;
	private String decisionName;
	private Date decisionDate;
	private String ownerUID;
	public AddDecisionBody() {
		// TODO Auto-generated constructor stub
	}
	
	
	public int getResponsabilityId() {
		return responsabilityId;
	}
	public void setResponsabilityId(int responsabilityId) {
		this.responsabilityId = responsabilityId;
	}
	public String getDecisionName() {
		return decisionName;
	}
	public void setDecisionName(String decisionName) {
		this.decisionName = decisionName;
	}
	public Date getDecisionDate() {
		return decisionDate;
	}
	public void setDecisionDate(Date decisionDate) {
		this.decisionDate = decisionDate;
	}
	public String getOwnerUID() {
		return ownerUID;
	}
	public void setOwnerUID(String ownerUID) {
		this.ownerUID = ownerUID;
	}


	@Override
	public String toString() {
		return "AddDecisionBody [responsabilityId=" + responsabilityId + ", decisionName=" + decisionName
				+ ", decisionDate=" + decisionDate + ", ownerUID=" + ownerUID + "]";
	}
}
